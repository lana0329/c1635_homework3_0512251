/*
 * Copyright 2019 Jonathan Chang, Chun-yien <ccy@musicapoetica.org>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package art.cctcc.c1635.antsomg.demo.y;

import static art.cctcc.c1635.antsomg.demo.y.Vertex_Y.Y.*;
import tech.metacontext.ocnhfa.antsomg.impl.StandardGraph;

/**
 *
 * @author Yun Chen Lee <jenny0329lamina@gmail.com>
 */
public class Graph_Y extends StandardGraph<Edge_Y, Vertex_Y> {

    public Graph_Y(double alpha, double beta) {

        super(alpha, beta);
        setFraction_mode(StandardGraph.FractionMode.Power);
    }

    @Override
    public void init_graph() {

        var stay = Vertex_Y.get(STAY);
        var plus = Vertex_Y.get(PLUS);
        var minus = Vertex_Y.get(MINUS);

        this.setStart(stay);

        var S_P = new Edge_Y(stay, plus, 10.0);
        var P_S = new Edge_Y(plus, stay, 1.0);
        var S_M = new Edge_Y(stay, minus, 1.0);
        var M_S = new Edge_Y(minus, stay, 1.0);
        var P_P = new Edge_Y(plus, plus, 100.0);
        var M_M = new Edge_Y(minus, minus, 1.0);
        var S_S = new Edge_Y(stay, stay, 50.0);
        
        this.addEdges(
                S_P,P_S,S_M,M_S,P_P,M_M,S_S);
    }

}
