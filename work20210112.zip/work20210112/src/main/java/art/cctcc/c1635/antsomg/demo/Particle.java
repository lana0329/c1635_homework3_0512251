/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo;
import processing.core.PVector;

/**
 *
 * @author Yun Chen Lee <jenny0329lamina@gmail.com>
 */
public class Particle {
  PVector p;
  float deg,shakeDeg;
  float r,shakeR;
  PVector c;
  String mode;
  float size;
  int scale,count;
  boolean ifShake;
  
  public Particle(){
    this.p=new PVector(0,0);
    this.deg=0;
    this.r=0;
    this.c=new PVector(255,255,255);
    this.mode="GOOUT";
    this.count=0;
    this.scale=50;
    this.shakeDeg=0;
    this.ifShake=false;
  }
  
  public Particle(PVector _c,float _deg,int _scale){
    this.p=new PVector(0,0);
    this.deg=_deg;
    this.r=0;
    this.c=_c;
    this.mode="GOOUT";
    this.count=0;
    this.scale=_scale;
    this.shakeDeg=0;
    this.ifShake=false;
  }
  
  public void changeMode(String _mode){
    boolean canChange=true;
    if(_mode=="TURNRIGHT"||_mode=="TURNLEFT"){
      if(this.mode=="TURNRIGHT"||this.mode=="TURNLEFT")canChange=false;
    }
    else if(_mode=="GOOUT"||_mode=="STAYIN"){
      if(this.mode=="GOOUT"||this.mode=="STAYIN")canChange=false;
    }
    else if(_mode=="SHAKE"&&this.ifShake==false){
      if(this.mode!="GOOUT"&&this.mode!="STAYIN"){
        this.ifShake=true;
        this.shakeR=this.r;
        this.shakeDeg=0;
      }
      canChange=false;
    }
    
    
    if(canChange){
      this.mode=_mode;
      this.ifShake=false;
    }
  }
  
  public void changeScale(String _scaleStatus){
    if(_scaleStatus=="PLUS") this.scale+=((int)Math.random()*5)*3;
    else if((_scaleStatus=="MINUS")&&(this.scale>20)) this.scale-=((int)Math.random()*5)*3;
  }
 
  public void computeP(){
    this.p.x=this.r*(float)Math.cos(Math.toRadians(this.deg));
    this.p.y=this.r*(float)Math.sin(Math.toRadians(this.deg));
  }
  
  public void run(String _mode,String _scaleStatus){
    this.size=3.8f-(this.r/(float)Math.sqrt(Math.pow(400,2)*2))*(3-0.8f);
    if(this.count<this.scale){
      switch(this.mode){
        case "GOOUT":
          this.r++;
          break;
        case "STAYIN":
          if(r>0)this.r--; 
          else this.count=this.scale;
          break;
        case "TURNRIGHT":
          this.deg+=0.5;
          break;
        case "TURNLEFT":
          this.deg-=0.5;
          break;
      }
      if(this.ifShake){
        float amplitude=(this.shakeR/(float)Math.sqrt(Math.pow(400,2)*2))*(20-8)+8;
        this.r=this.shakeR+(float)Math.sin(this.shakeDeg)*amplitude;
        shakeDeg+=Math.PI/15;
      }
      this.computeP();
      count++;
    }
    else{
      changeMode(_mode);
      this.count=0;
      changeScale(_scaleStatus);
    }
  }
}
