/*
 * Copyright 2019 Jonathan Chang, Chun-yien <ccy@musicapoetica.org>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package art.cctcc.c1635.antsomg.demo;

import java.awt.Color;
import java.util.Map;
import static java.util.function.Predicate.not;
import java.util.stream.Collectors;
import processing.core.PApplet;
import tech.metacontext.ocnhfa.antsomg.impl.StandardGraph;
import processing.core.PVector;
import java.util.ArrayList; 

/**
 *
 *  @author Yun Chen Lee <jenny0329lamina@gmail.com>
 */
public class Main extends PApplet {

    int size = 800;
    SpiralSystem demo;
    int population=360;

    @Override
    public void settings() {
        size(size, size);
    }

    @Override
    public void setup() {
        colorMode(RGB);
        background(0);
        noFill();
        blendMode(REPLACE);
        demo = new SpiralSystem(population);
        demo.init_graphs();
        demo.init_population();
        ArrayList <PVector> colorArray=new ArrayList<>();
        PVector red=new PVector(230,57,70);
        PVector blueLight=new PVector(241,250,238);
        PVector blue=new PVector(168,218,220);
        PVector blueDark=new PVector(69,123,157);
        PVector black=new PVector(29,53,87);
        PVector yellow=new PVector(252,163,17);
        colorArray.add(red);
        colorArray.add(blueLight);
        colorArray.add(blue);
        colorArray.add(blueDark);
        colorArray.add(black);
        colorArray.add(yellow);
        int count=0;
        for(SpiralAnt ant:demo.ants){
            float _deg=count*360/population;
            PVector _c=colorArray.get((int)(Math.random()*6));
            int _scale=20;  
            ant.setParticle(_c,_deg,_scale);
            count++;
        }
        //delay(10000);
    }
    float move_amount = 2.5f;
    float delta_theta = 1f;

    @Override
    public void draw() {

        demo.ants.stream()
                .filter(not(SpiralAnt::isCompleted))
                .forEach(ant -> {
                    var _mode = ant.getCurrentTrace().getDimension("x").getName();
                    var _scaleStatus = ant.getCurrentTrace().getDimension("y").getName();
                    push();
                        translate(width/2,height/2);
                        
                        System.out.println(_mode);
                        
                        ant.p.run(_mode,_scaleStatus);
                        fill(ant.p.c.x,ant.p.c.y,ant.p.c.z);
                        noStroke();
                        circle(ant.p.p.x,ant.p.p.y,ant.p.size);
                    pop();
                });

        if (demo.isAimAchieved()) {
            demo.getGraphs().values().stream()
                    .map(StandardGraph::asGraphviz)
                    .forEach(System.out::println);
            noLoop();
        } else {
            demo.navigate();
        }
    }

    public static void main(String[] args) {
        System.setProperty("sun.java2d.uiScale", "1.0");
        PApplet.main(Main.class);
    }
}
