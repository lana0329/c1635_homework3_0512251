/*
 * Copyright 2019 Jonathan Chang, Chun-yien <ccy@musicapoetica.org>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package art.cctcc.c1635.antsomg.demo.x;

import art.cctcc.c1635.antsomg.demo.x.Vertex_X.*;
import tech.metacontext.ocnhfa.antsomg.impl.StandardGraph;

/**
 *
 * @author Yun Chen Lee <jenny0329lamina@gmail.com>
 */
public class Graph_X extends StandardGraph<Edge_X, Vertex_X> {

    public Graph_X(double alpha, double beta) {

        super(alpha, beta);
        setFraction_mode(StandardGraph.FractionMode.Power);
    }

    @Override
    public void init_graph() {

        var goOut = Vertex_X.get(X.GOOUT);
        var stayIn = Vertex_X.get(X.STAYIN);
        var turnRight = Vertex_X.get(X.TURNRIGHT);
        var turnleft = Vertex_X.get(X.TURNLEFT);
        var shake = Vertex_X.get(X.SHAKE);

        this.setStart(goOut);
        var O_O = new Edge_X(goOut, goOut, 1000.0);
        var O_R = new Edge_X(goOut, turnRight, 1.0);
        var O_L = new Edge_X(goOut, turnleft, 1.0);
        var R_O = new Edge_X(turnRight, goOut, 500.0);
        var L_O = new Edge_X(turnleft, goOut, 500.0);
        var I_R = new Edge_X(stayIn, turnRight, 1.0);
        var I_L = new Edge_X(stayIn, turnleft, 1.0);
        var R_I = new Edge_X(turnRight, stayIn, 0.1);
        var L_I = new Edge_X(turnleft, stayIn, 0.1);
        var S_S = new Edge_X(shake, shake, 1.0);
        var S_O = new Edge_X(shake, goOut, 500.0);
        var S_L = new Edge_X(shake, turnleft, 1.0);
        var S_R = new Edge_X(shake, turnRight, 1.0);
        var O_S = new Edge_X(goOut, shake, 1.0);
        var I_S = new Edge_X(stayIn, shake, 1.0);
        var R_S = new Edge_X(turnRight, shake, 1.0);
        var L_S = new Edge_X(turnleft, shake, 1.0);
                
        
        this.addEdges(
                O_O,
                O_R,O_L,
                R_O,L_O,
                I_R,I_L,
                R_I,L_I,
                S_S,S_O,S_R,S_L,
                O_S,I_S,R_S,L_S
        );
    }
}
